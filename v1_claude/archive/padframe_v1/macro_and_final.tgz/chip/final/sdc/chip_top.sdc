###############################################################################
# Created by write_sdc
###############################################################################
current_design chip_top
###############################################################################
# Timing Constraints
###############################################################################
create_clock -name clk_PAD -period 40.0000 [get_pins {clk_pad/Y}]
set_clock_transition 0.1500 [get_clocks {clk_PAD}]
set_clock_uncertainty 0.2500 clk_PAD
set_propagated_clock [get_clocks {clk_PAD}]
set_input_delay 0.0000 -clock [get_clocks {clk_PAD}] -min -add_delay [get_ports {bidir_PAD[0]}]
set_input_delay 8.0000 -clock [get_clocks {clk_PAD}] -max -add_delay [get_ports {bidir_PAD[0]}]
set_input_delay 0.0000 -clock [get_clocks {clk_PAD}] -min -add_delay [get_ports {bidir_PAD[1]}]
set_input_delay 8.0000 -clock [get_clocks {clk_PAD}] -max -add_delay [get_ports {bidir_PAD[1]}]
set_input_delay 0.0000 -clock [get_clocks {clk_PAD}] -min -add_delay [get_ports {bidir_PAD[2]}]
set_input_delay 8.0000 -clock [get_clocks {clk_PAD}] -max -add_delay [get_ports {bidir_PAD[2]}]
set_input_delay 0.0000 -clock [get_clocks {clk_PAD}] -min -add_delay [get_ports {bidir_PAD[3]}]
set_input_delay 8.0000 -clock [get_clocks {clk_PAD}] -max -add_delay [get_ports {bidir_PAD[3]}]
set_input_delay 0.0000 -clock [get_clocks {clk_PAD}] -min -add_delay [get_ports {bidir_PAD[4]}]
set_input_delay 8.0000 -clock [get_clocks {clk_PAD}] -max -add_delay [get_ports {bidir_PAD[4]}]
set_input_delay 0.0000 -clock [get_clocks {clk_PAD}] -min -add_delay [get_ports {bidir_PAD[5]}]
set_input_delay 8.0000 -clock [get_clocks {clk_PAD}] -max -add_delay [get_ports {bidir_PAD[5]}]
set_input_delay 0.0000 -clock [get_clocks {clk_PAD}] -min -add_delay [get_ports {input_PAD[0]}]
set_input_delay 8.0000 -clock [get_clocks {clk_PAD}] -max -add_delay [get_ports {input_PAD[0]}]
set_input_delay 0.0000 -clock [get_clocks {clk_PAD}] -min -add_delay [get_ports {input_PAD[1]}]
set_input_delay 8.0000 -clock [get_clocks {clk_PAD}] -max -add_delay [get_ports {input_PAD[1]}]
set_input_delay 0.0000 -clock [get_clocks {clk_PAD}] -min -add_delay [get_ports {input_PAD[2]}]
set_input_delay 8.0000 -clock [get_clocks {clk_PAD}] -max -add_delay [get_ports {input_PAD[2]}]
set_input_delay 0.0000 -clock [get_clocks {clk_PAD}] -min -add_delay [get_ports {input_PAD[3]}]
set_input_delay 8.0000 -clock [get_clocks {clk_PAD}] -max -add_delay [get_ports {input_PAD[3]}]
set_input_delay 0.0000 -clock [get_clocks {clk_PAD}] -min -add_delay [get_ports {rst_n_PAD}]
set_input_delay 8.0000 -clock [get_clocks {clk_PAD}] -max -add_delay [get_ports {rst_n_PAD}]
set_output_delay 8.0000 -clock [get_clocks {clk_PAD}] -add_delay [get_ports {bidir_PAD[0]}]
set_output_delay 8.0000 -clock [get_clocks {clk_PAD}] -add_delay [get_ports {bidir_PAD[1]}]
set_output_delay 8.0000 -clock [get_clocks {clk_PAD}] -add_delay [get_ports {bidir_PAD[2]}]
set_output_delay 8.0000 -clock [get_clocks {clk_PAD}] -add_delay [get_ports {bidir_PAD[3]}]
set_output_delay 8.0000 -clock [get_clocks {clk_PAD}] -add_delay [get_ports {bidir_PAD[4]}]
set_output_delay 8.0000 -clock [get_clocks {clk_PAD}] -add_delay [get_ports {bidir_PAD[5]}]
set_multicycle_path -hold\
    -to [get_ports {bidir_PAD[5]}] 1
set_multicycle_path -setup\
    -to [get_ports {bidir_PAD[5]}] 2
###############################################################################
# Environment
###############################################################################
set_load -pin_load 0.0729 [get_ports {clk_PAD}]
set_load -pin_load 0.0729 [get_ports {rf_PAD}]
set_load -pin_load 0.0729 [get_ports {rst_n_PAD}]
set_load -pin_load 0.0729 [get_ports {analog_PAD[2]}]
set_load -pin_load 0.0729 [get_ports {analog_PAD[1]}]
set_load -pin_load 0.0729 [get_ports {analog_PAD[0]}]
set_load -pin_load 0.0729 [get_ports {bidir_PAD[5]}]
set_load -pin_load 0.0729 [get_ports {bidir_PAD[4]}]
set_load -pin_load 0.0729 [get_ports {bidir_PAD[3]}]
set_load -pin_load 0.0729 [get_ports {bidir_PAD[2]}]
set_load -pin_load 0.0729 [get_ports {bidir_PAD[1]}]
set_load -pin_load 0.0729 [get_ports {bidir_PAD[0]}]
set_load -pin_load 0.0729 [get_ports {input_PAD[3]}]
set_load -pin_load 0.0729 [get_ports {input_PAD[2]}]
set_load -pin_load 0.0729 [get_ports {input_PAD[1]}]
set_load -pin_load 0.0729 [get_ports {input_PAD[0]}]
set_timing_derate -early 0.9500
set_timing_derate -late 1.0500
###############################################################################
# Design Rules
###############################################################################
set_max_transition 3.0000 [current_design]
set_max_capacitance 0.2000 [current_design]
set_max_fanout 10.0000 [current_design]
